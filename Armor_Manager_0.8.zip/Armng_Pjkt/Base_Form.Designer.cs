﻿using System;

namespace Armng_Pjkt
{
    partial class Base_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
            "1 - Upper Head",
            "0",
            "0",
            "0"}, -1);
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
            "2- Face",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
            "3- Lower Head",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
            "4- Neck",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
            "5- Shoulders",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem6 = new System.Windows.Forms.ListViewItem(new string[] {
            "6- Chest",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem7 = new System.Windows.Forms.ListViewItem(new string[] {
            "7-Sides",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem8 = new System.Windows.Forms.ListViewItem(new string[] {
            "8- Belly",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem9 = new System.Windows.Forms.ListViewItem(new string[] {
            "9- Hips",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem10 = new System.Windows.Forms.ListViewItem(new string[] {
            "10- Groin",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem11 = new System.Windows.Forms.ListViewItem(new string[] {
            "11- Upper Arms",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem12 = new System.Windows.Forms.ListViewItem(new string[] {
            "12- Elbows",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem13 = new System.Windows.Forms.ListViewItem(new string[] {
            "13- Forearms",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem14 = new System.Windows.Forms.ListViewItem(new string[] {
            "14- Hands",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem15 = new System.Windows.Forms.ListViewItem(new string[] {
            "15- Thighs",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem16 = new System.Windows.Forms.ListViewItem(new string[] {
            "16- Knees",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem17 = new System.Windows.Forms.ListViewItem(new string[] {
            "17- Shins",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem18 = new System.Windows.Forms.ListViewItem(new string[] {
            "18- Feet",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem19 = new System.Windows.Forms.ListViewItem(new string[] {
            "19- Upper Back",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.ListViewItem listViewItem20 = new System.Windows.Forms.ListViewItem(new string[] {
            "20- Lower Back",
            "",
            "",
            "",
            ""}, -1);
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Head");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Torso");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Arms");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Legs");
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Base_Form));
            this.Location = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AVC = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AVP = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AVB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.listView1 = new System.Windows.Forms.ListView();
            this.cost_l = new System.Windows.Forms.Label();
            this.wt_L = new System.Windows.Forms.Label();
            this.quality_textbox = new System.Windows.Forms.TextBox();
            this.pp_l = new System.Windows.Forms.Label();
            this.coverage_txtbox = new System.Windows.Forms.TextBox();
            this.avb_l = new System.Windows.Forms.Label();
            this.avp_l = new System.Windows.Forms.Label();
            this.avc_l = new System.Windows.Forms.Label();
            this.type = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.weighlabel = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label32 = new System.Windows.Forms.Label();
            this.avb18n = new System.Windows.Forms.NumericUpDown();
            this.avp18n = new System.Windows.Forms.NumericUpDown();
            this.avc18n = new System.Windows.Forms.NumericUpDown();
            this.label33 = new System.Windows.Forms.Label();
            this.avb17n = new System.Windows.Forms.NumericUpDown();
            this.avp17n = new System.Windows.Forms.NumericUpDown();
            this.avc17n = new System.Windows.Forms.NumericUpDown();
            this.label34 = new System.Windows.Forms.Label();
            this.avb16n = new System.Windows.Forms.NumericUpDown();
            this.avp16n = new System.Windows.Forms.NumericUpDown();
            this.avc16n = new System.Windows.Forms.NumericUpDown();
            this.label35 = new System.Windows.Forms.Label();
            this.avb15n = new System.Windows.Forms.NumericUpDown();
            this.avp15n = new System.Windows.Forms.NumericUpDown();
            this.avc15n = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.avb14n = new System.Windows.Forms.NumericUpDown();
            this.avp14n = new System.Windows.Forms.NumericUpDown();
            this.avc14n = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.avb13n = new System.Windows.Forms.NumericUpDown();
            this.avp13n = new System.Windows.Forms.NumericUpDown();
            this.avc13n = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.avb12n = new System.Windows.Forms.NumericUpDown();
            this.avp12n = new System.Windows.Forms.NumericUpDown();
            this.avc12n = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.avb11n = new System.Windows.Forms.NumericUpDown();
            this.avp11n = new System.Windows.Forms.NumericUpDown();
            this.avc11n = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.avb20n = new System.Windows.Forms.NumericUpDown();
            this.avp20n = new System.Windows.Forms.NumericUpDown();
            this.avc20n = new System.Windows.Forms.NumericUpDown();
            this.label25 = new System.Windows.Forms.Label();
            this.avb19n = new System.Windows.Forms.NumericUpDown();
            this.avp19n = new System.Windows.Forms.NumericUpDown();
            this.avc19n = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.avb10n = new System.Windows.Forms.NumericUpDown();
            this.avp10n = new System.Windows.Forms.NumericUpDown();
            this.avc10n = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.avb9n = new System.Windows.Forms.NumericUpDown();
            this.avp9n = new System.Windows.Forms.NumericUpDown();
            this.avc9n = new System.Windows.Forms.NumericUpDown();
            this.label20 = new System.Windows.Forms.Label();
            this.avb8n = new System.Windows.Forms.NumericUpDown();
            this.avp8n = new System.Windows.Forms.NumericUpDown();
            this.avc8n = new System.Windows.Forms.NumericUpDown();
            this.label21 = new System.Windows.Forms.Label();
            this.avb7n = new System.Windows.Forms.NumericUpDown();
            this.avp7n = new System.Windows.Forms.NumericUpDown();
            this.avc7n = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.avb6n = new System.Windows.Forms.NumericUpDown();
            this.avp6n = new System.Windows.Forms.NumericUpDown();
            this.avc6n = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.avb5n = new System.Windows.Forms.NumericUpDown();
            this.avp5n = new System.Windows.Forms.NumericUpDown();
            this.avc5n = new System.Windows.Forms.NumericUpDown();
            this.label19 = new System.Windows.Forms.Label();
            this.avb4n = new System.Windows.Forms.NumericUpDown();
            this.avp4n = new System.Windows.Forms.NumericUpDown();
            this.avc4n = new System.Windows.Forms.NumericUpDown();
            this.label18 = new System.Windows.Forms.Label();
            this.avb3n = new System.Windows.Forms.NumericUpDown();
            this.avp3n = new System.Windows.Forms.NumericUpDown();
            this.avc3n = new System.Windows.Forms.NumericUpDown();
            this.label17 = new System.Windows.Forms.Label();
            this.avb2n = new System.Windows.Forms.NumericUpDown();
            this.avp2n = new System.Windows.Forms.NumericUpDown();
            this.avc2n = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.avb1n = new System.Windows.Forms.NumericUpDown();
            this.avp1n = new System.Windows.Forms.NumericUpDown();
            this.avc1n = new System.Windows.Forms.NumericUpDown();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.remove_node = new System.Windows.Forms.Button();
            this.treeView_l1 = new System.Windows.Forms.TreeView();
            this.menuStrip4 = new System.Windows.Forms.MenuStrip();
            this.l1_addbutton = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.label36 = new System.Windows.Forms.Label();
            this.pplabel = new System.Windows.Forms.Label();
            this.menuStrip5 = new System.Windows.Forms.MenuStrip();
            this.menuStrip6 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avb18n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp18n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc18n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb17n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp17n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc17n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb16n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp16n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc16n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb15n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp15n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc15n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb14n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp14n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc14n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb13n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp13n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc13n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb12n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp12n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc12n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb11n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp11n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc11n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb20n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp20n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc20n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb19n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp19n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc19n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb10n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp10n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc10n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb9n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp9n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc9n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb8n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp8n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc8n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb7n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp7n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc7n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb6n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp6n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc6n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb5n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp5n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc5n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb4n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp4n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc4n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb3n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp3n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc3n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb2n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp2n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc2n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb1n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp1n)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc1n)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.menuStrip4.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.menuStrip6.SuspendLayout();
            this.SuspendLayout();
            // 
            // Location
            // 
            this.Location.Text = "Location";
            this.Location.Width = 113;
            // 
            // AVC
            // 
            this.AVC.Text = "AVC";
            // 
            // AVP
            // 
            this.AVP.Text = "AVP";
            // 
            // AVB
            // 
            this.AVB.Text = "AVB";
            this.AVB.Width = 67;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.SystemColors.MenuBar;
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Location,
            this.AVC,
            this.AVP,
            this.AVB});
            this.listView1.GridLines = true;
            this.listView1.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2,
            listViewItem3,
            listViewItem4,
            listViewItem5,
            listViewItem6,
            listViewItem7,
            listViewItem8,
            listViewItem9,
            listViewItem10,
            listViewItem11,
            listViewItem12,
            listViewItem13,
            listViewItem14,
            listViewItem15,
            listViewItem16,
            listViewItem17,
            listViewItem18,
            listViewItem19,
            listViewItem20});
            this.listView1.Location = new System.Drawing.Point(515, 143);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(312, 474);
            this.listView1.TabIndex = 31;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // cost_l
            // 
            this.cost_l.AutoSize = true;
            this.cost_l.Location = new System.Drawing.Point(267, 381);
            this.cost_l.Name = "cost_l";
            this.cost_l.Size = new System.Drawing.Size(19, 13);
            this.cost_l.TabIndex = 37;
            this.cost_l.Text = "----";
            // 
            // wt_L
            // 
            this.wt_L.AutoSize = true;
            this.wt_L.Location = new System.Drawing.Point(267, 368);
            this.wt_L.Name = "wt_L";
            this.wt_L.Size = new System.Drawing.Size(19, 13);
            this.wt_L.TabIndex = 36;
            this.wt_L.Text = "----";
            // 
            // quality_textbox
            // 
            this.quality_textbox.Location = new System.Drawing.Point(240, 310);
            this.quality_textbox.Multiline = true;
            this.quality_textbox.Name = "quality_textbox";
            this.quality_textbox.ReadOnly = true;
            this.quality_textbox.Size = new System.Drawing.Size(234, 38);
            this.quality_textbox.TabIndex = 35;
            // 
            // pp_l
            // 
            this.pp_l.AutoSize = true;
            this.pp_l.Location = new System.Drawing.Point(267, 355);
            this.pp_l.Name = "pp_l";
            this.pp_l.Size = new System.Drawing.Size(19, 13);
            this.pp_l.TabIndex = 34;
            this.pp_l.Text = "----";
            // 
            // coverage_txtbox
            // 
            this.coverage_txtbox.Location = new System.Drawing.Point(240, 244);
            this.coverage_txtbox.Multiline = true;
            this.coverage_txtbox.Name = "coverage_txtbox";
            this.coverage_txtbox.ReadOnly = true;
            this.coverage_txtbox.Size = new System.Drawing.Size(234, 38);
            this.coverage_txtbox.TabIndex = 33;
            // 
            // avb_l
            // 
            this.avb_l.AutoSize = true;
            this.avb_l.Location = new System.Drawing.Point(281, 210);
            this.avb_l.Name = "avb_l";
            this.avb_l.Size = new System.Drawing.Size(19, 13);
            this.avb_l.TabIndex = 32;
            this.avb_l.Text = "----";
            // 
            // avp_l
            // 
            this.avp_l.AutoSize = true;
            this.avp_l.Location = new System.Drawing.Point(281, 188);
            this.avp_l.Name = "avp_l";
            this.avp_l.Size = new System.Drawing.Size(19, 13);
            this.avp_l.TabIndex = 31;
            this.avp_l.Text = "----";
            // 
            // avc_l
            // 
            this.avc_l.AutoSize = true;
            this.avc_l.Location = new System.Drawing.Point(281, 166);
            this.avc_l.Name = "avc_l";
            this.avc_l.Size = new System.Drawing.Size(19, 13);
            this.avc_l.TabIndex = 30;
            this.avc_l.Text = "----";
            // 
            // type
            // 
            this.type.AutoSize = true;
            this.type.Location = new System.Drawing.Point(281, 143);
            this.type.Name = "type";
            this.type.Size = new System.Drawing.Size(19, 13);
            this.type.TabIndex = 29;
            this.type.Text = "----";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(237, 381);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 28;
            this.label9.Text = "Cost:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(237, 368);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(24, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "Wt:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(237, 355);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(24, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "PP:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(237, 294);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Qualities:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(240, 228);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Coverage:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(240, 210);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "AVB:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(240, 188);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(31, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "AVP:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(240, 166);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 38;
            this.label11.Text = "AVC:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(240, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(34, 13);
            this.label12.TabIndex = 39;
            this.label12.Text = "Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 24);
            this.label3.TabIndex = 40;
            this.label3.Text = "Weight:";
            // 
            // weighlabel
            // 
            this.weighlabel.AutoSize = true;
            this.weighlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weighlabel.Location = new System.Drawing.Point(100, 81);
            this.weighlabel.Name = "weighlabel";
            this.weighlabel.Size = new System.Drawing.Size(16, 18);
            this.weighlabel.TabIndex = 41;
            this.weighlabel.Text = "0";
            this.weighlabel.Click += new System.EventHandler(this.weighlabel_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label32);
            this.tabPage5.Controls.Add(this.avb18n);
            this.tabPage5.Controls.Add(this.avp18n);
            this.tabPage5.Controls.Add(this.avc18n);
            this.tabPage5.Controls.Add(this.label33);
            this.tabPage5.Controls.Add(this.avb17n);
            this.tabPage5.Controls.Add(this.avp17n);
            this.tabPage5.Controls.Add(this.avc17n);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.avb16n);
            this.tabPage5.Controls.Add(this.avp16n);
            this.tabPage5.Controls.Add(this.avc16n);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.avb15n);
            this.tabPage5.Controls.Add(this.avp15n);
            this.tabPage5.Controls.Add(this.avc15n);
            this.tabPage5.Controls.Add(this.label28);
            this.tabPage5.Controls.Add(this.avb14n);
            this.tabPage5.Controls.Add(this.avp14n);
            this.tabPage5.Controls.Add(this.avc14n);
            this.tabPage5.Controls.Add(this.label29);
            this.tabPage5.Controls.Add(this.avb13n);
            this.tabPage5.Controls.Add(this.avp13n);
            this.tabPage5.Controls.Add(this.avc13n);
            this.tabPage5.Controls.Add(this.label30);
            this.tabPage5.Controls.Add(this.avb12n);
            this.tabPage5.Controls.Add(this.avp12n);
            this.tabPage5.Controls.Add(this.avc12n);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Controls.Add(this.avb11n);
            this.tabPage5.Controls.Add(this.avp11n);
            this.tabPage5.Controls.Add(this.avc11n);
            this.tabPage5.Controls.Add(this.label24);
            this.tabPage5.Controls.Add(this.avb20n);
            this.tabPage5.Controls.Add(this.avp20n);
            this.tabPage5.Controls.Add(this.avc20n);
            this.tabPage5.Controls.Add(this.label25);
            this.tabPage5.Controls.Add(this.avb19n);
            this.tabPage5.Controls.Add(this.avp19n);
            this.tabPage5.Controls.Add(this.avc19n);
            this.tabPage5.Controls.Add(this.label26);
            this.tabPage5.Controls.Add(this.avb10n);
            this.tabPage5.Controls.Add(this.avp10n);
            this.tabPage5.Controls.Add(this.avc10n);
            this.tabPage5.Controls.Add(this.label27);
            this.tabPage5.Controls.Add(this.avb9n);
            this.tabPage5.Controls.Add(this.avp9n);
            this.tabPage5.Controls.Add(this.avc9n);
            this.tabPage5.Controls.Add(this.label20);
            this.tabPage5.Controls.Add(this.avb8n);
            this.tabPage5.Controls.Add(this.avp8n);
            this.tabPage5.Controls.Add(this.avc8n);
            this.tabPage5.Controls.Add(this.label21);
            this.tabPage5.Controls.Add(this.avb7n);
            this.tabPage5.Controls.Add(this.avp7n);
            this.tabPage5.Controls.Add(this.avc7n);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.avb6n);
            this.tabPage5.Controls.Add(this.avp6n);
            this.tabPage5.Controls.Add(this.avc6n);
            this.tabPage5.Controls.Add(this.label23);
            this.tabPage5.Controls.Add(this.avb5n);
            this.tabPage5.Controls.Add(this.avp5n);
            this.tabPage5.Controls.Add(this.avc5n);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.avb4n);
            this.tabPage5.Controls.Add(this.avp4n);
            this.tabPage5.Controls.Add(this.avc4n);
            this.tabPage5.Controls.Add(this.label18);
            this.tabPage5.Controls.Add(this.avb3n);
            this.tabPage5.Controls.Add(this.avp3n);
            this.tabPage5.Controls.Add(this.avc3n);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.avb2n);
            this.tabPage5.Controls.Add(this.avp2n);
            this.tabPage5.Controls.Add(this.avc2n);
            this.tabPage5.Controls.Add(this.label16);
            this.tabPage5.Controls.Add(this.label15);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.avb1n);
            this.tabPage5.Controls.Add(this.avp1n);
            this.tabPage5.Controls.Add(this.avc1n);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(211, 509);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Layering Bonuses & Modifiers";
            this.tabPage5.UseVisualStyleBackColor = true;
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 471);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(46, 13);
            this.label32.TabIndex = 94;
            this.label32.Text = "18- Feet";
            // 
            // avb18n
            // 
            this.avb18n.Location = new System.Drawing.Point(164, 469);
            this.avb18n.Name = "avb18n";
            this.avb18n.Size = new System.Drawing.Size(30, 20);
            this.avb18n.TabIndex = 93;
            this.avb18n.ValueChanged += new System.EventHandler(this.avb18n_ValueChanged);
            // 
            // avp18n
            // 
            this.avp18n.Location = new System.Drawing.Point(128, 469);
            this.avp18n.Name = "avp18n";
            this.avp18n.Size = new System.Drawing.Size(30, 20);
            this.avp18n.TabIndex = 92;
            this.avp18n.ValueChanged += new System.EventHandler(this.avp18n_ValueChanged);
            // 
            // avc18n
            // 
            this.avc18n.Location = new System.Drawing.Point(92, 469);
            this.avc18n.Name = "avc18n";
            this.avc18n.Size = new System.Drawing.Size(30, 20);
            this.avc18n.TabIndex = 91;
            this.avc18n.ValueChanged += new System.EventHandler(this.avc18n_ValueChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 449);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(51, 13);
            this.label33.TabIndex = 90;
            this.label33.Text = "17- Shins";
            // 
            // avb17n
            // 
            this.avb17n.Location = new System.Drawing.Point(164, 447);
            this.avb17n.Name = "avb17n";
            this.avb17n.Size = new System.Drawing.Size(30, 20);
            this.avb17n.TabIndex = 89;
            this.avb17n.ValueChanged += new System.EventHandler(this.avb17n_ValueChanged);
            // 
            // avp17n
            // 
            this.avp17n.Location = new System.Drawing.Point(128, 447);
            this.avp17n.Name = "avp17n";
            this.avp17n.Size = new System.Drawing.Size(30, 20);
            this.avp17n.TabIndex = 88;
            this.avp17n.ValueChanged += new System.EventHandler(this.avp17n_ValueChanged);
            // 
            // avc17n
            // 
            this.avc17n.Location = new System.Drawing.Point(92, 447);
            this.avc17n.Name = "avc17n";
            this.avc17n.Size = new System.Drawing.Size(30, 20);
            this.avc17n.TabIndex = 87;
            this.avc17n.ValueChanged += new System.EventHandler(this.avc17n_ValueChanged);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(9, 427);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 13);
            this.label34.TabIndex = 86;
            this.label34.Text = "16- Knees";
            // 
            // avb16n
            // 
            this.avb16n.Location = new System.Drawing.Point(164, 425);
            this.avb16n.Name = "avb16n";
            this.avb16n.Size = new System.Drawing.Size(30, 20);
            this.avb16n.TabIndex = 85;
            this.avb16n.ValueChanged += new System.EventHandler(this.avb16n_ValueChanged);
            // 
            // avp16n
            // 
            this.avp16n.Location = new System.Drawing.Point(128, 425);
            this.avp16n.Name = "avp16n";
            this.avp16n.Size = new System.Drawing.Size(30, 20);
            this.avp16n.TabIndex = 84;
            this.avp16n.ValueChanged += new System.EventHandler(this.avp16n_ValueChanged);
            // 
            // avc16n
            // 
            this.avc16n.Location = new System.Drawing.Point(92, 425);
            this.avc16n.Name = "avc16n";
            this.avc16n.Size = new System.Drawing.Size(30, 20);
            this.avc16n.TabIndex = 83;
            this.avc16n.ValueChanged += new System.EventHandler(this.avc16n_ValueChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 406);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(57, 13);
            this.label35.TabIndex = 82;
            this.label35.Text = "15- Thighs";
            // 
            // avb15n
            // 
            this.avb15n.Location = new System.Drawing.Point(164, 404);
            this.avb15n.Name = "avb15n";
            this.avb15n.Size = new System.Drawing.Size(30, 20);
            this.avb15n.TabIndex = 81;
            this.avb15n.ValueChanged += new System.EventHandler(this.avb15n_ValueChanged);
            // 
            // avp15n
            // 
            this.avp15n.Location = new System.Drawing.Point(128, 404);
            this.avp15n.Name = "avp15n";
            this.avp15n.Size = new System.Drawing.Size(30, 20);
            this.avp15n.TabIndex = 80;
            this.avp15n.ValueChanged += new System.EventHandler(this.avp15n_ValueChanged);
            // 
            // avc15n
            // 
            this.avc15n.Location = new System.Drawing.Point(92, 404);
            this.avc15n.Name = "avc15n";
            this.avc15n.Size = new System.Drawing.Size(30, 20);
            this.avc15n.TabIndex = 79;
            this.avc15n.ValueChanged += new System.EventHandler(this.avc15n_ValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(9, 376);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(56, 13);
            this.label28.TabIndex = 78;
            this.label28.Text = "14- Hands";
            // 
            // avb14n
            // 
            this.avb14n.Location = new System.Drawing.Point(164, 374);
            this.avb14n.Name = "avb14n";
            this.avb14n.Size = new System.Drawing.Size(30, 20);
            this.avb14n.TabIndex = 77;
            this.avb14n.ValueChanged += new System.EventHandler(this.avb14n_ValueChanged);
            // 
            // avp14n
            // 
            this.avp14n.Location = new System.Drawing.Point(128, 374);
            this.avp14n.Name = "avp14n";
            this.avp14n.Size = new System.Drawing.Size(30, 20);
            this.avp14n.TabIndex = 76;
            this.avp14n.ValueChanged += new System.EventHandler(this.avp14n_ValueChanged);
            // 
            // avc14n
            // 
            this.avc14n.Location = new System.Drawing.Point(92, 374);
            this.avc14n.Name = "avc14n";
            this.avc14n.Size = new System.Drawing.Size(30, 20);
            this.avc14n.TabIndex = 75;
            this.avc14n.ValueChanged += new System.EventHandler(this.avc14n_ValueChanged);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 354);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(68, 13);
            this.label29.TabIndex = 74;
            this.label29.Text = "13- Forearms";
            // 
            // avb13n
            // 
            this.avb13n.Location = new System.Drawing.Point(164, 352);
            this.avb13n.Name = "avb13n";
            this.avb13n.Size = new System.Drawing.Size(30, 20);
            this.avb13n.TabIndex = 73;
            this.avb13n.ValueChanged += new System.EventHandler(this.avb13n_ValueChanged);
            // 
            // avp13n
            // 
            this.avp13n.Location = new System.Drawing.Point(128, 352);
            this.avp13n.Name = "avp13n";
            this.avp13n.Size = new System.Drawing.Size(30, 20);
            this.avp13n.TabIndex = 72;
            this.avp13n.ValueChanged += new System.EventHandler(this.avp13n_ValueChanged);
            // 
            // avc13n
            // 
            this.avc13n.Location = new System.Drawing.Point(92, 352);
            this.avc13n.Name = "avc13n";
            this.avc13n.Size = new System.Drawing.Size(30, 20);
            this.avc13n.TabIndex = 71;
            this.avc13n.ValueChanged += new System.EventHandler(this.avc13n_ValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(9, 332);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 13);
            this.label30.TabIndex = 70;
            this.label30.Text = "12- Elbows";
            // 
            // avb12n
            // 
            this.avb12n.Location = new System.Drawing.Point(164, 330);
            this.avb12n.Name = "avb12n";
            this.avb12n.Size = new System.Drawing.Size(30, 20);
            this.avb12n.TabIndex = 69;
            this.avb12n.ValueChanged += new System.EventHandler(this.avb12n_ValueChanged);
            // 
            // avp12n
            // 
            this.avp12n.Location = new System.Drawing.Point(128, 330);
            this.avp12n.Name = "avp12n";
            this.avp12n.Size = new System.Drawing.Size(30, 20);
            this.avp12n.TabIndex = 68;
            this.avp12n.ValueChanged += new System.EventHandler(this.avp12n_ValueChanged);
            // 
            // avc12n
            // 
            this.avc12n.Location = new System.Drawing.Point(92, 330);
            this.avc12n.Name = "avc12n";
            this.avc12n.Size = new System.Drawing.Size(30, 20);
            this.avc12n.TabIndex = 67;
            this.avc12n.ValueChanged += new System.EventHandler(this.avc12n_ValueChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(9, 311);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(80, 13);
            this.label31.TabIndex = 66;
            this.label31.Text = "11- Upper Arms";
            // 
            // avb11n
            // 
            this.avb11n.Location = new System.Drawing.Point(164, 309);
            this.avb11n.Name = "avb11n";
            this.avb11n.Size = new System.Drawing.Size(30, 20);
            this.avb11n.TabIndex = 65;
            this.avb11n.ValueChanged += new System.EventHandler(this.avb11n_ValueChanged);
            // 
            // avp11n
            // 
            this.avp11n.Location = new System.Drawing.Point(128, 309);
            this.avp11n.Name = "avp11n";
            this.avp11n.Size = new System.Drawing.Size(30, 20);
            this.avp11n.TabIndex = 64;
            this.avp11n.ValueChanged += new System.EventHandler(this.avp11n_ValueChanged);
            // 
            // avc11n
            // 
            this.avc11n.Location = new System.Drawing.Point(92, 309);
            this.avc11n.Name = "avc11n";
            this.avc11n.Size = new System.Drawing.Size(30, 20);
            this.avc11n.TabIndex = 63;
            this.avc11n.ValueChanged += new System.EventHandler(this.avc11n_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(9, 277);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 13);
            this.label24.TabIndex = 62;
            this.label24.Text = "20- Lower Back";
            // 
            // avb20n
            // 
            this.avb20n.Location = new System.Drawing.Point(164, 275);
            this.avb20n.Name = "avb20n";
            this.avb20n.Size = new System.Drawing.Size(30, 20);
            this.avb20n.TabIndex = 61;
            this.avb20n.ValueChanged += new System.EventHandler(this.avb20n_ValueChanged);
            // 
            // avp20n
            // 
            this.avp20n.Location = new System.Drawing.Point(128, 275);
            this.avp20n.Name = "avp20n";
            this.avp20n.Size = new System.Drawing.Size(30, 20);
            this.avp20n.TabIndex = 60;
            this.avp20n.ValueChanged += new System.EventHandler(this.avp20n_ValueChanged);
            // 
            // avc20n
            // 
            this.avc20n.Location = new System.Drawing.Point(92, 275);
            this.avc20n.Name = "avc20n";
            this.avc20n.Size = new System.Drawing.Size(30, 20);
            this.avc20n.TabIndex = 59;
            this.avc20n.ValueChanged += new System.EventHandler(this.avc20n_ValueChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(9, 255);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 13);
            this.label25.TabIndex = 58;
            this.label25.Text = "19- Upper Back";
            // 
            // avb19n
            // 
            this.avb19n.Location = new System.Drawing.Point(164, 253);
            this.avb19n.Name = "avb19n";
            this.avb19n.Size = new System.Drawing.Size(30, 20);
            this.avb19n.TabIndex = 57;
            this.avb19n.ValueChanged += new System.EventHandler(this.avb19n_ValueChanged);
            // 
            // avp19n
            // 
            this.avp19n.Location = new System.Drawing.Point(128, 253);
            this.avp19n.Name = "avp19n";
            this.avp19n.Size = new System.Drawing.Size(30, 20);
            this.avp19n.TabIndex = 56;
            this.avp19n.ValueChanged += new System.EventHandler(this.avp19n_ValueChanged);
            // 
            // avc19n
            // 
            this.avc19n.Location = new System.Drawing.Point(92, 253);
            this.avc19n.Name = "avc19n";
            this.avc19n.Size = new System.Drawing.Size(30, 20);
            this.avc19n.TabIndex = 55;
            this.avc19n.ValueChanged += new System.EventHandler(this.avc19n_ValueChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(9, 233);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(53, 13);
            this.label26.TabIndex = 54;
            this.label26.Text = "10 - Groin";
            // 
            // avb10n
            // 
            this.avb10n.Location = new System.Drawing.Point(164, 231);
            this.avb10n.Name = "avb10n";
            this.avb10n.Size = new System.Drawing.Size(30, 20);
            this.avb10n.TabIndex = 53;
            this.avb10n.ValueChanged += new System.EventHandler(this.avb10n_ValueChanged);
            // 
            // avp10n
            // 
            this.avp10n.Location = new System.Drawing.Point(128, 231);
            this.avp10n.Name = "avp10n";
            this.avp10n.Size = new System.Drawing.Size(30, 20);
            this.avp10n.TabIndex = 52;
            this.avp10n.ValueChanged += new System.EventHandler(this.avp10n_ValueChanged);
            // 
            // avc10n
            // 
            this.avc10n.Location = new System.Drawing.Point(92, 231);
            this.avc10n.Name = "avc10n";
            this.avc10n.Size = new System.Drawing.Size(30, 20);
            this.avc10n.TabIndex = 51;
            this.avc10n.ValueChanged += new System.EventHandler(this.avc10n_ValueChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(9, 212);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(40, 13);
            this.label27.TabIndex = 50;
            this.label27.Text = "9- Hips";
            // 
            // avb9n
            // 
            this.avb9n.Location = new System.Drawing.Point(164, 210);
            this.avb9n.Name = "avb9n";
            this.avb9n.Size = new System.Drawing.Size(30, 20);
            this.avb9n.TabIndex = 49;
            this.avb9n.ValueChanged += new System.EventHandler(this.avb9n_ValueChanged);
            // 
            // avp9n
            // 
            this.avp9n.Location = new System.Drawing.Point(128, 210);
            this.avp9n.Name = "avp9n";
            this.avp9n.Size = new System.Drawing.Size(30, 20);
            this.avp9n.TabIndex = 48;
            this.avp9n.ValueChanged += new System.EventHandler(this.avp9n_ValueChanged);
            // 
            // avc9n
            // 
            this.avc9n.Location = new System.Drawing.Point(92, 210);
            this.avc9n.Name = "avc9n";
            this.avc9n.Size = new System.Drawing.Size(30, 20);
            this.avc9n.TabIndex = 47;
            this.avc9n.ValueChanged += new System.EventHandler(this.avc9n_ValueChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(9, 190);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(41, 13);
            this.label20.TabIndex = 46;
            this.label20.Text = "8- Belly";
            // 
            // avb8n
            // 
            this.avb8n.Location = new System.Drawing.Point(164, 188);
            this.avb8n.Name = "avb8n";
            this.avb8n.Size = new System.Drawing.Size(30, 20);
            this.avb8n.TabIndex = 45;
            this.avb8n.ValueChanged += new System.EventHandler(this.avb8n_ValueChanged);
            // 
            // avp8n
            // 
            this.avp8n.Location = new System.Drawing.Point(128, 188);
            this.avp8n.Name = "avp8n";
            this.avp8n.Size = new System.Drawing.Size(30, 20);
            this.avp8n.TabIndex = 44;
            this.avp8n.ValueChanged += new System.EventHandler(this.avp8n_ValueChanged);
            // 
            // avc8n
            // 
            this.avc8n.Location = new System.Drawing.Point(92, 188);
            this.avc8n.Name = "avc8n";
            this.avc8n.Size = new System.Drawing.Size(30, 20);
            this.avc8n.TabIndex = 43;
            this.avc8n.ValueChanged += new System.EventHandler(this.avc8n_ValueChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(9, 168);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(45, 13);
            this.label21.TabIndex = 42;
            this.label21.Text = "7- Sides";
            // 
            // avb7n
            // 
            this.avb7n.Location = new System.Drawing.Point(164, 166);
            this.avb7n.Name = "avb7n";
            this.avb7n.Size = new System.Drawing.Size(30, 20);
            this.avb7n.TabIndex = 41;
            this.avb7n.ValueChanged += new System.EventHandler(this.avb7n_ValueChanged);
            // 
            // avp7n
            // 
            this.avp7n.Location = new System.Drawing.Point(128, 166);
            this.avp7n.Name = "avp7n";
            this.avp7n.Size = new System.Drawing.Size(30, 20);
            this.avp7n.TabIndex = 40;
            this.avp7n.ValueChanged += new System.EventHandler(this.avp7n_ValueChanged);
            // 
            // avc7n
            // 
            this.avc7n.Location = new System.Drawing.Point(92, 166);
            this.avc7n.Name = "avc7n";
            this.avc7n.Size = new System.Drawing.Size(30, 20);
            this.avc7n.TabIndex = 39;
            this.avc7n.ValueChanged += new System.EventHandler(this.avc7n_ValueChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 146);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(46, 13);
            this.label22.TabIndex = 38;
            this.label22.Text = "6- Chest";
            // 
            // avb6n
            // 
            this.avb6n.Location = new System.Drawing.Point(164, 144);
            this.avb6n.Name = "avb6n";
            this.avb6n.Size = new System.Drawing.Size(30, 20);
            this.avb6n.TabIndex = 37;
            this.avb6n.ValueChanged += new System.EventHandler(this.avb6n_ValueChanged);
            // 
            // avp6n
            // 
            this.avp6n.Location = new System.Drawing.Point(128, 144);
            this.avp6n.Name = "avp6n";
            this.avp6n.Size = new System.Drawing.Size(30, 20);
            this.avp6n.TabIndex = 36;
            this.avp6n.ValueChanged += new System.EventHandler(this.avp6n_ValueChanged);
            // 
            // avc6n
            // 
            this.avc6n.Location = new System.Drawing.Point(92, 144);
            this.avc6n.Name = "avc6n";
            this.avc6n.Size = new System.Drawing.Size(30, 20);
            this.avc6n.TabIndex = 35;
            this.avc6n.ValueChanged += new System.EventHandler(this.avc6n_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 125);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 13);
            this.label23.TabIndex = 34;
            this.label23.Text = "5- Shoulders";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // avb5n
            // 
            this.avb5n.Location = new System.Drawing.Point(164, 123);
            this.avb5n.Name = "avb5n";
            this.avb5n.Size = new System.Drawing.Size(30, 20);
            this.avb5n.TabIndex = 30;
            this.avb5n.ValueChanged += new System.EventHandler(this.avb5n_ValueChanged);
            // 
            // avp5n
            // 
            this.avp5n.Location = new System.Drawing.Point(128, 123);
            this.avp5n.Name = "avp5n";
            this.avp5n.Size = new System.Drawing.Size(30, 20);
            this.avp5n.TabIndex = 29;
            this.avp5n.ValueChanged += new System.EventHandler(this.avp5n_ValueChanged);
            // 
            // avc5n
            // 
            this.avc5n.Location = new System.Drawing.Point(92, 123);
            this.avc5n.Name = "avc5n";
            this.avc5n.Size = new System.Drawing.Size(30, 20);
            this.avc5n.TabIndex = 28;
            this.avc5n.ValueChanged += new System.EventHandler(this.avc5n_ValueChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(9, 94);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(45, 13);
            this.label19.TabIndex = 27;
            this.label19.Text = "4- Neck";
            // 
            // avb4n
            // 
            this.avb4n.Location = new System.Drawing.Point(164, 92);
            this.avb4n.Name = "avb4n";
            this.avb4n.Size = new System.Drawing.Size(30, 20);
            this.avb4n.TabIndex = 26;
            this.avb4n.ValueChanged += new System.EventHandler(this.avb4n_ValueChanged);
            // 
            // avp4n
            // 
            this.avp4n.Location = new System.Drawing.Point(128, 92);
            this.avp4n.Name = "avp4n";
            this.avp4n.Size = new System.Drawing.Size(30, 20);
            this.avp4n.TabIndex = 25;
            this.avp4n.ValueChanged += new System.EventHandler(this.avp4n_ValueChanged);
            // 
            // avc4n
            // 
            this.avc4n.Location = new System.Drawing.Point(92, 92);
            this.avc4n.Name = "avc4n";
            this.avc4n.Size = new System.Drawing.Size(30, 20);
            this.avc4n.TabIndex = 24;
            this.avc4n.ValueChanged += new System.EventHandler(this.avc4n_ValueChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 72);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(77, 13);
            this.label18.TabIndex = 23;
            this.label18.Text = "3- Lower Head";
            // 
            // avb3n
            // 
            this.avb3n.Location = new System.Drawing.Point(164, 70);
            this.avb3n.Name = "avb3n";
            this.avb3n.Size = new System.Drawing.Size(30, 20);
            this.avb3n.TabIndex = 22;
            this.avb3n.ValueChanged += new System.EventHandler(this.avb3n_ValueChanged);
            // 
            // avp3n
            // 
            this.avp3n.Location = new System.Drawing.Point(128, 70);
            this.avp3n.Name = "avp3n";
            this.avp3n.Size = new System.Drawing.Size(30, 20);
            this.avp3n.TabIndex = 21;
            this.avp3n.ValueChanged += new System.EventHandler(this.avp3n_ValueChanged);
            // 
            // avc3n
            // 
            this.avc3n.Location = new System.Drawing.Point(92, 70);
            this.avc3n.Name = "avc3n";
            this.avc3n.Size = new System.Drawing.Size(30, 20);
            this.avc3n.TabIndex = 20;
            this.avc3n.ValueChanged += new System.EventHandler(this.avc3n_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(9, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 13);
            this.label17.TabIndex = 19;
            this.label17.Text = "2- Face";
            // 
            // avb2n
            // 
            this.avb2n.Location = new System.Drawing.Point(164, 48);
            this.avb2n.Name = "avb2n";
            this.avb2n.Size = new System.Drawing.Size(30, 20);
            this.avb2n.TabIndex = 18;
            this.avb2n.ValueChanged += new System.EventHandler(this.avb2n_ValueChanged);
            // 
            // avp2n
            // 
            this.avp2n.Location = new System.Drawing.Point(128, 48);
            this.avp2n.Name = "avp2n";
            this.avp2n.Size = new System.Drawing.Size(30, 20);
            this.avp2n.TabIndex = 17;
            this.avp2n.ValueChanged += new System.EventHandler(this.av2pn_ValueChanged);
            // 
            // avc2n
            // 
            this.avc2n.Location = new System.Drawing.Point(92, 48);
            this.avc2n.Name = "avc2n";
            this.avc2n.Size = new System.Drawing.Size(30, 20);
            this.avc2n.TabIndex = 16;
            this.avc2n.ValueChanged += new System.EventHandler(this.avc2n_ValueChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 13);
            this.label16.TabIndex = 15;
            this.label16.Text = "1- Upper Head";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(161, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(28, 13);
            this.label15.TabIndex = 5;
            this.label15.Text = "AVB";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(128, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(28, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "AVP";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(94, 11);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(28, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "AVC";
            // 
            // avb1n
            // 
            this.avb1n.Location = new System.Drawing.Point(164, 27);
            this.avb1n.Name = "avb1n";
            this.avb1n.Size = new System.Drawing.Size(30, 20);
            this.avb1n.TabIndex = 2;
            this.avb1n.ValueChanged += new System.EventHandler(this.avb1n_ValueChanged);
            // 
            // avp1n
            // 
            this.avp1n.Location = new System.Drawing.Point(128, 27);
            this.avp1n.Name = "avp1n";
            this.avp1n.Size = new System.Drawing.Size(30, 20);
            this.avp1n.TabIndex = 1;
            this.avp1n.ValueChanged += new System.EventHandler(this.avp1n_ValueChanged);
            // 
            // avc1n
            // 
            this.avc1n.Location = new System.Drawing.Point(92, 27);
            this.avc1n.Name = "avc1n";
            this.avc1n.Size = new System.Drawing.Size(30, 20);
            this.avc1n.TabIndex = 0;
            this.avc1n.ValueChanged += new System.EventHandler(this.avc1n_ValueChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.remove_node);
            this.tabPage4.Controls.Add(this.treeView_l1);
            this.tabPage4.Controls.Add(this.menuStrip4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(211, 509);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "Armor";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // remove_node
            // 
            this.remove_node.Location = new System.Drawing.Point(181, 4);
            this.remove_node.Name = "remove_node";
            this.remove_node.Size = new System.Drawing.Size(29, 23);
            this.remove_node.TabIndex = 2;
            this.remove_node.Text = "X";
            this.remove_node.UseVisualStyleBackColor = true;
            this.remove_node.Click += new System.EventHandler(this.remove_node_Click);
            // 
            // treeView_l1
            // 
            this.treeView_l1.Location = new System.Drawing.Point(7, 30);
            this.treeView_l1.Name = "treeView_l1";
            treeNode1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            treeNode1.Checked = true;
            treeNode1.Name = "Head";
            treeNode1.Text = "Head";
            treeNode2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            treeNode2.Name = "Torso";
            treeNode2.Text = "Torso";
            treeNode3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            treeNode3.Name = "Arms";
            treeNode3.Text = "Arms";
            treeNode4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            treeNode4.Name = "Legs";
            treeNode4.Text = "Legs";
            this.treeView_l1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3,
            treeNode4});
            this.treeView_l1.ShowNodeToolTips = true;
            this.treeView_l1.Size = new System.Drawing.Size(203, 437);
            this.treeView_l1.TabIndex = 1;
            this.treeView_l1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_l1_AfterSelect);
            // 
            // menuStrip4
            // 
            this.menuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.l1_addbutton});
            this.menuStrip4.Location = new System.Drawing.Point(3, 3);
            this.menuStrip4.Name = "menuStrip4";
            this.menuStrip4.Size = new System.Drawing.Size(205, 24);
            this.menuStrip4.TabIndex = 0;
            this.menuStrip4.Text = "menuStrip4";
            // 
            // l1_addbutton
            // 
            this.l1_addbutton.Name = "l1_addbutton";
            this.l1_addbutton.Size = new System.Drawing.Size(41, 20);
            this.l1_addbutton.Text = "Add";
            this.l1_addbutton.Click += new System.EventHandler(this.l1_addbutton_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 121);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(219, 535);
            this.tabControl1.TabIndex = 0;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(22, 57);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(36, 20);
            this.label36.TabIndex = 42;
            this.label36.Text = "PP:";
            // 
            // pplabel
            // 
            this.pplabel.AutoSize = true;
            this.pplabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pplabel.Location = new System.Drawing.Point(64, 57);
            this.pplabel.Name = "pplabel";
            this.pplabel.Size = new System.Drawing.Size(16, 18);
            this.pplabel.TabIndex = 43;
            this.pplabel.Text = "0";
            // 
            // menuStrip5
            // 
            this.menuStrip5.Location = new System.Drawing.Point(0, 24);
            this.menuStrip5.Name = "menuStrip5";
            this.menuStrip5.Size = new System.Drawing.Size(847, 24);
            this.menuStrip5.TabIndex = 44;
            this.menuStrip5.Text = "menuStrip5";
            // 
            // menuStrip6
            // 
            this.menuStrip6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip6.Location = new System.Drawing.Point(0, 0);
            this.menuStrip6.Name = "menuStrip6";
            this.menuStrip6.Size = new System.Drawing.Size(847, 24);
            this.menuStrip6.TabIndex = 45;
            this.menuStrip6.Text = "menuStrip6";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.openToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Base_Form
            // 
            this.ClientSize = new System.Drawing.Size(847, 661);
            this.Controls.Add(this.pplabel);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.weighlabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.cost_l);
            this.Controls.Add(this.wt_L);
            this.Controls.Add(this.quality_textbox);
            this.Controls.Add(this.pp_l);
            this.Controls.Add(this.coverage_txtbox);
            this.Controls.Add(this.avb_l);
            this.Controls.Add(this.avp_l);
            this.Controls.Add(this.avc_l);
            this.Controls.Add(this.type);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip5);
            this.Controls.Add(this.menuStrip6);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip4;
            this.Name = "Base_Form";
            this.Text = "Jarv\'s Armor Tools v0.1";
            this.Load += new System.EventHandler(this.Base_Form_Load);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.avb18n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp18n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc18n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb17n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp17n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc17n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb16n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp16n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc16n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb15n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp15n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc15n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb14n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp14n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc14n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb13n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp13n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc13n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb12n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp12n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc12n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb11n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp11n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc11n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb20n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp20n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc20n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb19n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp19n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc19n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb10n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp10n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc10n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb9n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp9n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc9n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb8n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp8n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc8n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb7n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp7n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc7n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb6n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp6n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc6n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb5n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp5n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc5n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb4n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp4n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc4n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb3n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp3n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc3n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb2n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp2n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc2n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avb1n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avp1n)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.avc1n)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.menuStrip4.ResumeLayout(false);
            this.menuStrip4.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.menuStrip6.ResumeLayout(false);
            this.menuStrip6.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Base_Form_Load(object sender, EventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void deleteToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl Armor_Tab;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addArmorToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem1;
        private System.Windows.Forms.MenuStrip menuStrip3;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ColumnHeader Location;
        private System.Windows.Forms.ColumnHeader AVC;
        private System.Windows.Forms.ColumnHeader AVP;
        private System.Windows.Forms.ColumnHeader AVB;
        private System.Windows.Forms.Label cost_l;
        private System.Windows.Forms.Label wt_L;
        private System.Windows.Forms.TextBox quality_textbox;
        private System.Windows.Forms.Label pp_l;
        private System.Windows.Forms.TextBox coverage_txtbox;
        private System.Windows.Forms.Label avb_l;
        private System.Windows.Forms.Label avp_l;
        private System.Windows.Forms.Label avc_l;
        private System.Windows.Forms.Label type;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label weighlabel;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown avb18n;
        private System.Windows.Forms.NumericUpDown avp18n;
        private System.Windows.Forms.NumericUpDown avc18n;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.NumericUpDown avb17n;
        private System.Windows.Forms.NumericUpDown avp17n;
        private System.Windows.Forms.NumericUpDown avc17n;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown avb16n;
        private System.Windows.Forms.NumericUpDown avp16n;
        private System.Windows.Forms.NumericUpDown avc16n;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown avb15n;
        private System.Windows.Forms.NumericUpDown avp15n;
        private System.Windows.Forms.NumericUpDown avc15n;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown avb14n;
        private System.Windows.Forms.NumericUpDown avp14n;
        private System.Windows.Forms.NumericUpDown avc14n;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown avb13n;
        private System.Windows.Forms.NumericUpDown avp13n;
        private System.Windows.Forms.NumericUpDown avc13n;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown avb12n;
        private System.Windows.Forms.NumericUpDown avp12n;
        private System.Windows.Forms.NumericUpDown avc12n;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown avb11n;
        private System.Windows.Forms.NumericUpDown avp11n;
        private System.Windows.Forms.NumericUpDown avc11n;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown avb20n;
        private System.Windows.Forms.NumericUpDown avp20n;
        private System.Windows.Forms.NumericUpDown avc20n;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.NumericUpDown avb19n;
        private System.Windows.Forms.NumericUpDown avp19n;
        private System.Windows.Forms.NumericUpDown avc19n;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.NumericUpDown avb10n;
        private System.Windows.Forms.NumericUpDown avp10n;
        private System.Windows.Forms.NumericUpDown avc10n;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown avb9n;
        private System.Windows.Forms.NumericUpDown avp9n;
        private System.Windows.Forms.NumericUpDown avc9n;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.NumericUpDown avb8n;
        private System.Windows.Forms.NumericUpDown avp8n;
        private System.Windows.Forms.NumericUpDown avc8n;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown avb7n;
        private System.Windows.Forms.NumericUpDown avp7n;
        private System.Windows.Forms.NumericUpDown avc7n;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown avb6n;
        private System.Windows.Forms.NumericUpDown avp6n;
        private System.Windows.Forms.NumericUpDown avc6n;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.NumericUpDown avb5n;
        private System.Windows.Forms.NumericUpDown avp5n;
        private System.Windows.Forms.NumericUpDown avc5n;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.NumericUpDown avb4n;
        private System.Windows.Forms.NumericUpDown avp4n;
        private System.Windows.Forms.NumericUpDown avc4n;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.NumericUpDown avb3n;
        private System.Windows.Forms.NumericUpDown avp3n;
        private System.Windows.Forms.NumericUpDown avc3n;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.NumericUpDown avb2n;
        private System.Windows.Forms.NumericUpDown avp2n;
        private System.Windows.Forms.NumericUpDown avc2n;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.NumericUpDown avb1n;
        private System.Windows.Forms.NumericUpDown avp1n;
        private System.Windows.Forms.NumericUpDown avc1n;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button remove_node;
        private System.Windows.Forms.TreeView treeView_l1;
        private System.Windows.Forms.MenuStrip menuStrip4;
        private System.Windows.Forms.ToolStripMenuItem l1_addbutton;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label pplabel;
        private System.Windows.Forms.MenuStrip menuStrip5;
        private System.Windows.Forms.MenuStrip menuStrip6;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

